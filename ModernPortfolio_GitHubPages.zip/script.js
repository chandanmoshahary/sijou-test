const c=document.querySelector('.cursor');
document.addEventListener('mousemove',e=>{c.style.left=e.clientX+'px';c.style.top=e.clientY+'px';});
const els=document.querySelectorAll('.card,.project,.hero-card,.contact-box');
els.forEach(el=>{el.style.opacity=0;el.style.transform='translateY(40px)';el.style.transition='all .8s';});
function reveal(){els.forEach(el=>{if(el.getBoundingClientRect().top<window.innerHeight-100){el.style.opacity=1;el.style.transform='translateY(0)';}})}
window.addEventListener('scroll',reveal);reveal();